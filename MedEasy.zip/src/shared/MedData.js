export const medData = [
    {
        id: 1,
        imgdir: 'assets/MedicineImg/Calpol/calpol_1.jpg'
    },
    {
        id: 2,
        imgdir: 'assets/MedicineImg/Benadryl/benadryl.jpg'
    },
    {
        id: 3,
        imgdir: 'assets/MedicineImg/Combiflam/combiflam_2.jpg'
    },
    {
        id: 4,
        imgdir: 'assets/MedicineImg/Galvus/galvus_1.jpg'
    },
    {
        id: 5,
        imgdir: 'assets/MedicineImg/Humdard/humdardsafi.jpg'
    },
    {
        id: 6,
        imgdir: 'assets/MedicineImg/Lactogen/lactogen.jpg'
    },
    {
        id: 7,
        imgdir: 'assets/MedicineImg/Stayfree/stayfree.jpg'
    },
    {
        id: 8,
        imgdir: 'assets/MedicineImg/Dettol/dettol.jpg'
    },
    {
        id: 9,
        imgdir: 'assets/MedicineImg/Gelusil/gelusil.jpg'
    },
    {
        id: 10,
        imgdir: 'assets/MedicineImg/Revital/revital.jpg'
    },
    {
        id: 11,
        imgdir: 'assets/MedicineImg/Crocin/crocin.jpg'
    },
    {
        id: 12,
        imgdir: 'assets/MedicineImg/Vicks/vicks.jpg'
    }
]